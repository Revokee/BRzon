===Associados Amazon Plugin===
Contributors: Revokee 
Donate link: http://www.wfp.org/
Tags: amazon wordpress plugin, amazon, associado, amazon.com.br
Requires at least: 3.0.1
Tested up to: 3.9.1
Stable tag: 1.0

Add Amazon.com.br produtc listing to your posts or pages.
Get items by Asin, keywords, category and browsenode.
You can choose from 3 display modes.

== Description ==

With BRzon you are able to add Amazon products into your posts or pages.

**Features:**

*   Just for Amazon.com.br Associates
*   Show products by Asin,  keywords, category and/or subcategory
*   Sort items by bestselling, price, reviews etc.
*   Set the number of products you wish to display 
*   Choose between 1, 2 or 3 column mode

